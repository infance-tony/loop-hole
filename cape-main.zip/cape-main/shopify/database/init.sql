-- Create Database
CREATE DATABASE shopify_db;

-- Connect to the database
\c shopify_db;

-- Create Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);

-- Create Products Table
CREATE TABLE IF NOT EXISTS products (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DOUBLE PRECISION NOT NULL,
    total_items_in_stock INTEGER NOT NULL,
    category_id BIGINT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Insert Sample Categories
INSERT INTO categories (name) VALUES 
    ('Food'),
    ('Mobiles'),
    ('Electronics'),
    ('Stationery');

-- Insert Sample Products
INSERT INTO products (name, price, total_items_in_stock, category_id) VALUES 
    ('Organic Apple', 3.99, 150, 1),
    ('iPhone 15 Pro', 999.99, 50, 2),
    ('Sony Headphones', 299.99, 75, 3),
    ('Notebook Set', 12.99, 200, 4);
