# Shopify - Full-Stack Application

A complete full-stack e-commerce application with Spring Boot backend, PostgreSQL database, and React frontend.

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Maven 3.6+
- Node.js 16+
- PostgreSQL 12+

### 1. Database Setup
```bash
# Create database
createdb shopify_db

# Or using psql
psql -U root
CREATE DATABASE shopify_db;
```

### 2. Start Backend
```bash
cd shopify/backend
mvn spring-boot:run
```
Backend will run on `http://localhost:8080`

### 3. Start Frontend
```bash
cd shopify/frontend
npm install
npm run dev
```
Frontend will run on `http://localhost:5173`

### 4. Access the Application
Open browser and navigate to: `http://localhost:5173`

**Login Credentials:** Any username/password (dummy authentication)

## 📁 Project Structure

```
shopify/
├── backend/              # Spring Boot REST API
│   ├── src/main/java/com/shopify/
│   │   ├── entity/      # JPA Entities
│   │   ├── repository/  # Data Access Layer
│   │   ├── service/     # Business Logic
│   │   ├── controller/  # REST Controllers
│   │   ├── dto/         # Data Transfer Objects
│   │   └── config/      # Configuration
│   └── pom.xml
├── frontend/            # React + Vite Application
│   ├── src/
│   │   ├── components/  # Reusable Components
│   │   ├── pages/       # Page Components
│   │   ├── services/    # API Services
│   │   └── lib/         # Utilities
│   └── package.json
└── database/            # Database Scripts
    └── init.sql
```

## 🎯 Features

### Backend (Spring Boot)
- RESTful API with Spring Boot 3.2
- PostgreSQL database with JPA/Hibernate
- Custom JPQL queries for aggregations
- CORS enabled for frontend
- Automatic data seeding on startup
- Lombok for reducing boilerplate

### Frontend (React)
- Modern React with Vite
- TailwindCSS for styling
- shadcn/ui component library
- Radix UI icons
- React Router for navigation
- Dark/Light theme toggle
- Responsive design
- Axios for API calls

### Pages
1. **Login Page** - Dummy authentication
2. **Dashboard** - Statistics and overview
3. **Admin Panel** - Product management

## 🔗 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard` | Get dashboard statistics |
| GET | `/api/products` | Get all products |

## 💾 Database Schema

### Categories Table
- `id` (BIGINT, Primary Key)
- `name` (VARCHAR)

### Products Table
- `id` (BIGINT, Primary Key)
- `name` (VARCHAR)
- `price` (DOUBLE)
- `total_items_in_stock` (INTEGER)
- `category_id` (BIGINT, Foreign Key)

## 📦 Sample Data

The application comes pre-loaded with:

**4 Categories:**
- Food
- Mobiles
- Electronics
- Stationery

**4 Products:**
- Organic Apple - $3.99 (150 in stock)
- iPhone 15 Pro - $999.99 (50 in stock)
- Sony Headphones - $299.99 (75 in stock)
- Notebook Set - $12.99 (200 in stock)

## 🛠️ Technology Stack

### Backend
- Spring Boot 3.2.0
- Spring Data JPA
- PostgreSQL Driver
- Lombok
- Maven

### Frontend
- React 18
- Vite 5
- TailwindCSS 3
- shadcn/ui
- Radix UI Icons
- React Router 6
- Axios

### Database
- PostgreSQL

## 📝 Configuration

### Backend Configuration
Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/shopify_db
spring.datasource.username=root
spring.datasource.password=root
server.port=8080
```

### Frontend Configuration
Edit `frontend/src/services/api.js`:
```javascript
const API_BASE_URL = 'http://localhost:8080/api';
```

## 🎨 UI Components

The application uses shadcn/ui components:
- Button
- Card
- Input
- Label
- Table
- Theme Toggle

All styled with TailwindCSS and supporting dark mode.

## 🌓 Theme Support

Toggle between light and dark themes using the theme switcher in the header.

## 🔍 Development Tips

### Hot Reload
- Frontend: Vite provides instant HMR (Hot Module Replacement)
- Backend: Use Spring Boot DevTools for automatic restart

### Debugging
- Frontend: Use React DevTools browser extension
- Backend: Enable debug logging in application.properties

### Database Management
- Use pgAdmin or DBeaver for GUI management
- Or use psql command-line tool

## 🚨 Troubleshooting

### Backend won't start
- Check if PostgreSQL is running
- Verify database credentials
- Ensure port 8080 is available

### Frontend can't connect to backend
- Verify backend is running on port 8080
- Check CORS configuration in WebConfig.java
- Check browser console for errors

### Database connection failed
- Verify PostgreSQL service is running
- Check database name is `shopify_db`
- Verify username/password: root/root

## 📄 License

This project is for educational purposes.

## 👥 Contributing

Feel free to submit issues and enhancement requests!

## 📧 Support

For questions or issues, please create an issue in the repository.

---

**Happy Coding! 🚀**
